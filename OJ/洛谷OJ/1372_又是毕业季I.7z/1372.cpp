#include <iostream>
#include <cstdio>
#include <cstdlib>

using namespace std;

int main() {
	int n, k; scanf("%d%d", &n, &k);
	printf("%d\n", n/k);
	return 0;
}
